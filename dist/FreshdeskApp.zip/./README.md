# Freshdesk Veeqo integration

Simple JQuery/javascript app to implement Veeqo API functionality.
Queries the Veeqo "/orders" endpoint with the Freshdesk ticket requester's Email and populates a list using the returned orders.

Created using the V2 Freshdesk app development kit.
[Freshdesk SDK Documentation](https://developers.freshdesk.com/v2/docs/quick-start/)
