$(document).ready(function () {
  $("#order-template-container").load("./templates/order.html");
  $("#item-template-container").load("./templates/item.html");
});
