const VEEQO_APP_URL = "https://app.veeqo.com/orders";
const VEEQO_API_URL = "https://api.veeqo.com/orders";
const VEEQO_APIKEY = "<%= iparam.apiKey %>";

const errorMsg = "Error caught, please close & re-open this window";
const noOrdersMsg = "No orders found";
