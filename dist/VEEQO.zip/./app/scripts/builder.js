function removeSpinner() {
  $(".spinner").hide();
}

function removeError() {
  $(".error").remove();
  $(".spinner").show();
}

// prettier-ignore
function buildError() {
  var wrapper = $(".fw-widget-wrapper")
  $("<div/>")
    .addClass("muted error")
    .text(errorMsg)
    .appendTo(wrapper)
}

function buildNavigation(orders) {
  $("#nav-container").show();
  $("#indicator").append(
    $.map(orders, function () {
      return $("<div/>");
    })
  );
}

function buildNoOrders() {
  var container = $("#order-container");
  $("<div/>")
    .addClass("muted")
    .addClass("centre")
    .text(noOrdersMsg)
    .appendTo(container);
}

function buildOrder(order) {
  const { number, id, line_items } = order;

  if (line_items.length === 1) {
    resizeContainer(260);
  } else if (line_items.length === 2) {
    resizeContainer(290);
  } else {
    resizeContainer(325);
  }

  var orderTmpl = $("#orderTemplate").tmpl(formatOrder(order));
  var itemsTmpls = $("#itemTemplate").tmpl(formatItems(line_items));

  updateHeader(number, id);
  updateIndicator(state.currentIndex);

  $("#order-container").empty().append(orderTmpl);
  $("#items").append(itemsTmpls);
}

function resizeContainer(size) {
  $("#order-container").css("max-height", size - 32 + "px");
  resize(client, size + "px");
  /*if (items.length === 1) {
    container.css("max-height", "228px");
    resize(client, "260px");
  } else if (items.length === 2) {
    container.css("max-height", "258px");
    resize(client, "290px");
  } else {
    container.css("max-height", "295px");
    resize(client, "325px");
  }*/
}

function updateHeader(text, id) {
  $("#header")
    .text(text)
    .attr("target", "_blank")
    .attr("href", `${VEEQO_APP_URL}/${id}`);
}

function updateIndicator(idx) {
  $("#indicator")
    .children()
    .removeClass("selected")
    .eq(idx)
    .addClass("selected");
}
